<?php
// telegram sender
$bot_token = "7152531362:AAGJtrjROccMr97KhJIJQSytPMpZuuDaSrE";
$chat_id = "5669222170";

?>